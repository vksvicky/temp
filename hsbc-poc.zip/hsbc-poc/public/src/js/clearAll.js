function clearAll(){
  globalApp.clearAll();
}
